# PennyWise – Home Budget Management and Expense Analysis System

A responsive fintech-style household finance dashboard built with HTML5, CSS3, Vanilla JavaScript, Flask, MySQL, Pandas, NumPy and Matplotlib.

## Project contents

- `app.py` – Flask routes, MySQL models, REST API and Pandas/Matplotlib analytics endpoints.
- `templates/` – Separate Jinja2 pages for Dashboard, Transactions, Budgets, Categories, Analytics, Savings Goals and Settings.
- `static/css/styles.css` – Responsive premium dashboard styling.
- `static/js/app.js` – Prototype CRUD, validation, charts, search, filters, calculations, CSV export and toast notifications.
- `database/schema.sql` – MySQL database and table definitions.

## 1. Run the frontend prototype

The UI runs in prototype mode using browser localStorage. This is useful for a quick university demonstration.

```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
python app.py
```

Create the MySQL database before using the Flask API:

```bash
mysql -u root -p < database/schema.sql
```

Set the database connection string before starting Flask.

**Windows PowerShell**
```powershell
$env:DATABASE_URL="mysql+pymysql://root:YOUR_PASSWORD@localhost/pennywise"
python app.py
```

**macOS/Linux**
```bash
export DATABASE_URL="mysql+pymysql://root:YOUR_PASSWORD@localhost/pennywise"
python app.py
```

Open http://127.0.0.1:5000

## 2. Switch from prototype storage to Flask API

The frontend is intentionally set to localStorage prototype mode in `templates/base.html`:

```js
window.PENNYWISE_CONFIG = { apiMode: false };
```

Set `apiMode: true` when the API-backed frontend adapter is enabled. The REST endpoints are scaffolded in `app.py`; connect the frontend's data functions to these endpoints before enabling it. Do not enable API mode until the database is configured and the starter categories are inserted.

## 3. API endpoints scaffolded

| Method | Endpoint |
|---|---|
| GET / POST | `/api/transactions` |
| PUT / DELETE | `/api/transactions/<id>` |
| GET / POST | `/api/categories` |
| PUT / DELETE | `/api/categories/<id>` |
| GET / POST | `/api/budgets` |
| PUT / DELETE | `/api/budgets/<id>` |
| GET | `/api/analytics/summary?month=YYYY-MM` |
| GET | `/api/analytics/monthly` |
| GET | `/api/analytics/categories?month=YYYY-MM` |
| GET | `/api/analytics/chart/categories` |
| GET | `/api/analytics/chart/monthly` |

## 4. Data analysis

- Pandas groups transactions by month and category.
- NumPy is included in the analysis stack and can be used for numerical operations as the analytics module expands.
- Matplotlib generates server-side PNG charts at `/api/analytics/chart/<chart_name>`.
- The frontend also draws lightweight prototype charts with the Canvas 2D API so the demo works before the database is connected.

## 5. Important next steps before production

This is a university project starter, not a production financial service. Add authentication, per-user ownership and authorization checks, CSRF protection, server-side validation, migrations, pagination, secure secret management, rate limiting, tests and deployment configuration before real users or financial data are involved.
