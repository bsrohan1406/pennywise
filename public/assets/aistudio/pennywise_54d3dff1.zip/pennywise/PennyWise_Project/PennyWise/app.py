from datetime import date, datetime
from decimal import Decimal
import io
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request, send_file
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "change-this-for-production")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
    "DATABASE_URL", "mysql+pymysql://root:password@localhost/pennywise"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


class Category(db.Model):
    __tablename__ = "categories"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    kind = db.Column(db.Enum("income", "expense"), nullable=False)
    color = db.Column(db.String(12), default="#10B981")


class Transaction(db.Model):
    __tablename__ = "transactions"
    id = db.Column(db.Integer, primary_key=True)
    kind = db.Column(db.Enum("income", "expense"), nullable=False)
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    transaction_date = db.Column(db.Date, nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    description = db.Column(db.String(255), default="")
    category = db.relationship("Category")


class Budget(db.Model):
    __tablename__ = "budgets"
    id = db.Column(db.Integer, primary_key=True)
    month = db.Column(db.String(7), nullable=False)  # YYYY-MM
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    amount = db.Column(db.Numeric(12, 2), nullable=False)
    category = db.relationship("Category")


class SavingsGoal(db.Model):
    __tablename__ = "savings_goals"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    target_amount = db.Column(db.Numeric(12, 2), nullable=False)
    current_amount = db.Column(db.Numeric(12, 2), default=0)


def transaction_dict(t):
    return {
        "id": t.id, "type": t.kind, "amount": float(t.amount),
        "date": t.transaction_date.isoformat(), "category_id": t.category_id,
        "category": t.category.name if t.category else "",
        "description": t.description or ""
    }


@app.route("/")
def dashboard():
    return render_template("dashboard.html", page="dashboard", title="Dashboard")


@app.route("/<page>")
def pages(page):
    allowed = {
        "transactions": "Transactions", "budgets": "Budgets",
        "categories": "Categories", "analytics": "Analytics",
        "goals": "Savings Goals", "settings": "Settings"
    }
    if page not in allowed:
        return render_template("404.html"), 404
    return render_template(f"{page}.html", page=page, title=allowed[page])


@app.get("/api/transactions")
def get_transactions():
    rows = Transaction.query.order_by(Transaction.transaction_date.desc()).all()
    return jsonify([transaction_dict(t) for t in rows])


@app.post("/api/transactions")
def add_transaction():
    data = request.get_json() or {}
    try:
        amount = Decimal(str(data["amount"]))
        if amount <= 0:
            raise ValueError("Amount must be positive")
        row = Transaction(
            kind=data["type"], amount=amount,
            transaction_date=date.fromisoformat(data["date"]),
            category_id=int(data["category_id"]),
            description=data.get("description", "").strip()
        )
        db.session.add(row)
        db.session.commit()
        return jsonify(transaction_dict(row)), 201
    except (KeyError, ValueError, TypeError) as exc:
        return jsonify(error=str(exc)), 400


@app.put("/api/transactions/<int:item_id>")
def update_transaction(item_id):
    row = Transaction.query.get_or_404(item_id)
    data = request.get_json() or {}
    try:
        row.kind = data["type"]
        row.amount = Decimal(str(data["amount"]))
        row.transaction_date = date.fromisoformat(data["date"])
        row.category_id = int(data["category_id"])
        row.description = data.get("description", "").strip()
        if row.amount <= 0:
            raise ValueError("Amount must be positive")
        db.session.commit()
        return jsonify(transaction_dict(row))
    except (KeyError, ValueError, TypeError) as exc:
        return jsonify(error=str(exc)), 400


@app.delete("/api/transactions/<int:item_id>")
def delete_transaction(item_id):
    row = Transaction.query.get_or_404(item_id)
    db.session.delete(row)
    db.session.commit()
    return jsonify(success=True)


@app.get("/api/categories")
def get_categories():
    return jsonify([{"id": c.id, "name": c.name, "type": c.kind, "color": c.color}
                    for c in Category.query.order_by(Category.name).all()])


@app.post("/api/categories")
def add_category():
    data = request.get_json() or {}
    if not data.get("name") or data.get("type") not in ("income", "expense"):
        return jsonify(error="A name and valid category type are required"), 400
    row = Category(name=data["name"].strip(), kind=data["type"], color=data.get("color", "#10B981"))
    db.session.add(row)
    db.session.commit()
    return jsonify({"id": row.id, "name": row.name, "type": row.kind, "color": row.color}), 201


@app.put("/api/categories/<int:item_id>")
def update_category(item_id):
    row = Category.query.get_or_404(item_id)
    data = request.get_json() or {}
    row.name = data.get("name", row.name).strip()
    row.kind = data.get("type", row.kind)
    row.color = data.get("color", row.color)
    db.session.commit()
    return jsonify({"id": row.id, "name": row.name, "type": row.kind, "color": row.color})


@app.delete("/api/categories/<int:item_id>")
def delete_category(item_id):
    row = Category.query.get_or_404(item_id)
    if Transaction.query.filter_by(category_id=item_id).first():
        return jsonify(error="This category is used by transactions"), 409
    db.session.delete(row)
    db.session.commit()
    return jsonify(success=True)


@app.get("/api/budgets")
def get_budgets():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    rows = Budget.query.filter_by(month=month).all()
    output = []
    for b in rows:
        spent = db.session.query(db.func.coalesce(db.func.sum(Transaction.amount), 0)).filter(
            Transaction.category_id == b.category_id,
            Transaction.kind == "expense",
            db.func.date_format(Transaction.transaction_date, "%Y-%m") == month
        ).scalar()
        output.append({"id": b.id, "month": b.month, "category_id": b.category_id,
                       "category": b.category.name, "amount": float(b.amount), "spent": float(spent)})
    return jsonify(output)


@app.post("/api/budgets")
def add_budget():
    data = request.get_json() or {}
    row = Budget(month=data["month"], category_id=int(data["category_id"]),
                 amount=Decimal(str(data["amount"])))
    db.session.add(row)
    db.session.commit()
    return jsonify({"id": row.id}), 201


@app.put("/api/budgets/<int:item_id>")
def update_budget(item_id):
    row = Budget.query.get_or_404(item_id)
    data = request.get_json() or {}
    row.month = data.get("month", row.month)
    row.category_id = int(data.get("category_id", row.category_id))
    row.amount = Decimal(str(data.get("amount", row.amount)))
    db.session.commit()
    return jsonify(success=True)


@app.delete("/api/budgets/<int:item_id>")
def delete_budget(item_id):
    row = Budget.query.get_or_404(item_id)
    db.session.delete(row)
    db.session.commit()
    return jsonify(success=True)


@app.get("/api/analytics/summary")
def analytics_summary():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    rows = Transaction.query.filter(
        db.func.date_format(Transaction.transaction_date, "%Y-%m") == month
    ).all()
    df = pd.DataFrame([{"type": t.kind, "amount": float(t.amount)} for t in rows])
    income = float(df.loc[df.type == "income", "amount"].sum()) if not df.empty else 0
    expenses = float(df.loc[df.type == "expense", "amount"].sum()) if not df.empty else 0
    return jsonify({"income": income, "expenses": expenses, "savings": income-expenses,
                    "savings_percentage": (income-expenses)/income*100 if income else 0})


@app.get("/api/analytics/monthly")
def analytics_monthly():
    rows = Transaction.query.all()
    df = pd.DataFrame([{"month": t.transaction_date.strftime("%Y-%m"),
                        "type": t.kind, "amount": float(t.amount)} for t in rows])
    if df.empty:
        return jsonify([])
    pivot = df.pivot_table(index="month", columns="type", values="amount",
                           aggfunc="sum", fill_value=0).reset_index()
    return jsonify(pivot.to_dict(orient="records"))


@app.get("/api/analytics/categories")
def analytics_categories():
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    rows = Transaction.query.filter(
        Transaction.kind == "expense",
        db.func.date_format(Transaction.transaction_date, "%Y-%m") == month
    ).all()
    df = pd.DataFrame([{"category": t.category.name, "amount": float(t.amount)} for t in rows])
    if df.empty:
        return jsonify([])
    grouped = df.groupby("category", as_index=False)["amount"].sum().sort_values("amount", ascending=False)
    return jsonify(grouped.to_dict(orient="records"))


@app.get("/api/analytics/chart/<chart_name>")
def analytics_chart(chart_name):
    """Matplotlib-generated chart image for the analytics page."""
    month = request.args.get("month", date.today().strftime("%Y-%m"))
    if chart_name == "categories":
        data = analytics_categories().get_json()
        fig, ax = plt.subplots(figsize=(7, 4))
        if data:
            ax.pie([x["amount"] for x in data], labels=[x["category"] for x in data],
                   autopct="%1.0f%%", startangle=90, wedgeprops={"width": .42})
        else:
            ax.text(.5, .5, "No expense data yet", ha="center", va="center")
        ax.set_title("Expense distribution")
    elif chart_name == "monthly":
        data = analytics_monthly().get_json()
        fig, ax = plt.subplots(figsize=(8, 4))
        if data:
            frame = pd.DataFrame(data).tail(8).set_index("month")
            frame.reindex(columns=["income", "expense"], fill_value=0).plot(kind="bar", ax=ax)
        else:
            ax.text(.5, .5, "No transaction data yet", ha="center", va="center")
        ax.set_title("Monthly income vs expenses")
        ax.set_ylabel("Amount (INR)")
    else:
        return jsonify(error="Unknown chart"), 404
    fig.tight_layout()
    output = io.BytesIO()
    fig.savefig(output, format="png", dpi=140, transparent=False)
    plt.close(fig)
    output.seek(0)
    return send_file(output, mimetype="image/png")


if __name__ == "__main__":
    app.run(debug=True)
