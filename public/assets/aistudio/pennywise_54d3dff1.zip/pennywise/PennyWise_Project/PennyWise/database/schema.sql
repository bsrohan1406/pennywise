CREATE DATABASE IF NOT EXISTS pennywise CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pennywise;

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  kind ENUM('income','expense') NOT NULL,
  color VARCHAR(12) DEFAULT '#10B981',
  UNIQUE KEY unique_category_name_kind (name, kind)
);

CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kind ENUM('income','expense') NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  transaction_date DATE NOT NULL,
  category_id INT NOT NULL,
  description VARCHAR(255),
  CONSTRAINT fk_transaction_category FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE budgets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  month CHAR(7) NOT NULL,
  category_id INT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  CONSTRAINT fk_budget_category FOREIGN KEY (category_id) REFERENCES categories(id),
  UNIQUE KEY unique_month_category (month, category_id)
);

CREATE TABLE savings_goals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  target_amount DECIMAL(12,2) NOT NULL,
  current_amount DECIMAL(12,2) DEFAULT 0
);

INSERT INTO categories (name,kind,color) VALUES
('Groceries','expense','#10B981'),('Rent','expense','#4B83D5'),
('Transportation','expense','#F59E0B'),('Healthcare','expense','#E87979'),
('Education','expense','#8B69D4'),('Entertainment','expense','#E6A45C'),
('Utilities','expense','#51A6B8'),('Shopping','expense','#D17FA8'),
('Salary','income','#10B981'),('Freelance','income','#4B83D5'),
('Other income','income','#8B69D4');
